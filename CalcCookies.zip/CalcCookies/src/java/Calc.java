/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author dam2
 */
@WebServlet(urlPatterns = {"/Calc"})
public class Calc extends HttpServlet {

    private int a, b, res = 0;
    private int more, morex;
    private Cookie sum;
    private Cookie[] cookies;
    final private String id = "id";
    private String operando1, operando2, calculo, go = "";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Calc</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div align=\"center\">\n"
                    + "            <h1>CALCULADORA</h1>\n"
                    + "            <div style=\"border-top-color: black; border-bottom-color: black; border-top-style:solid; border-bottom-style:solid;\">\n"
                    + "                <form action=\"/CalcCookies/Calc\" method=\"POST\">\n"
                    + "                    <p>\n"
                    + "                        <input type=\"text\" name=\"num1\">\n"
                    + "                        <select name=\"oper\">\n"
                    + "                            <option value=\"+\">+</option>\n"
                    + "                            <option value=\"-\">-</option>\n"
                    + "                            <option value=\"/\">/</option>\n"
                    + "                            <option value=\"*\">*</option>\n"
                    + "                        </select>\n"
                    + "                        <input type=\"text\" name=\"num2\">\n"
                    + "                    </p>\n"
                    + "                    <p>\n"
                    + "                        <button type=\"submit\" name=\"go\" value=\"normal\">¡Calcular!</button>\n"
                    + "                        \n"
                    + "                        <input type=\"reset\" value=\"Limpiar\">\n"
                    + "                        \n"
                    + "                        <button type=\"submit\" name=\"go\" value=\"acumulado\">Acumular</button>\n"
                    + "                    </p>\n");

            if (request.getParameterNames().hasMoreElements()) {

                String operando1x = request.getParameter("num1");
                String operando2x = request.getParameter("num2");
                String calculox = request.getParameter("oper");
                cookies = request.getCookies();
                a = Integer.parseInt(operando1x);
                b = Integer.parseInt(operando2x);

                go = request.getParameter("go");

                try {

                    if (go.equals("normal")) {
                        
                        switch (calculox) {
                            case "+":
                                res = a + b;
                                out.println("<p><h1>Si sumas " + a + " y " + b + " el resultado es " + res + "</h1>");                                
                                break;
                            case "-":
                                res = a - b;
                                out.println("<p><h1>Si restas " + a + " a " + b + " el resultado es " + res + "</h1>");                                
                                break;
                            case "/":
                                res = a / b;
                                out.println("<p><h1>Si divides " + a + " entre " + b + " el resultado es " + res + "</h1>");                                
                                break;
                            case "*":
                                res = a * b;
                                out.println("<p><h1>Si multiplicas " + a + " y " + b + " el resultado es " + res + "</h1>");                                
                                break;
                            default:
                                break;
                        }
                        more = res;

                    } else if (go.equals("acumulado")) {

                        more = Integer.parseInt(buscaCookie(cookies, id).getValue());
                        
                        switch (calculox) {
                            case "+":
                                res = a + b + more;
                                out.println("<p><h1>Si sumas " + a + " mas " + b + " mas " + more + " el resultado es " + res + "</h1>");                               
                                break;
                            case "-":
                                res = a - b - more;
                                out.println("<p><h1>Si restas " + a + " a " + b + " y a " + more + " el resultado es " + res + "</h1>");                               
                                break;
                            case "/":
                                res = a / b / more;
                                out.println("<p><h1>Si divides " + a + " entre " + b + " y entre " + more + " el resultado es " + res + "</h1>");                                
                                break;
                            case "*":
                                res = a * b * more;
                                out.println("<p><h1>Si multiplicas " + a + " y " + b + " y " + more + " el resultado es " + res + "</h1>");                                
                                break;
                            default:
                                break;
                        }
                        more = res;

                    }
                    sum = new Cookie(id, Integer.toString(more));
                    response.addCookie(sum);

                    out.println("</p></form>\n"
                            + "            </div>\n"
                            + "        </div>");

                } catch (Exception ex) {
                    out.println("<p><h1>Error, has de introducir números en los campos. </h1>");

                    out.println("</p></form>\n"
                            + "            </div>\n"
                            + "        </div>");

                }

                out.println("</body>");
                out.println("</html>");

            } else {
                out.println("</p></form>\n"
                        + "            </div>\n"
                        + "        </div>");
            }
        }

    }

    private Cookie buscaCookie(Cookie[] cookie, String cookieName) {
        Cookie cookiez = null;
        if (cookies.length != 0) {
            Boolean token = false;
            int i = 0;
            while (!token) {
                cookiez = cookie[i];
                if (cookieName.equals(cookiez.getName())) {
                    token = true;
                }
                i++;
            }

        } else {

            return null;
        }

        return cookiez;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
